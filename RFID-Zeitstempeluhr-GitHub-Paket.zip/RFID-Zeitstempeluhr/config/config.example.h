#pragma once

// Kopiere diese Datei nach:
// src/config.h
//
// Danach deine eigenen Werte eintragen.
// Diese Datei NICHT in ein öffentliches GitHub-Repository einchecken.

#define WIFI_SSID       "DeinWLAN"
#define WIFI_PASSWORD   "DeinPasswort"

#define ADMIN_UID       "AB12CD34"
