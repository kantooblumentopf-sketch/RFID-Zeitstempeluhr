# Hardware-Notizen

## Projekt

RFID-Zeitstempeluhr

## Bekannte Hardware

- ESP32
- ESP32-2432S028
- PN532 RFID
- DS3231 RTC
- ursprünglich SSD1306 OLED 128x64
- später ILI9341V SPI-Display
- XPT2046 Touchscreen
- Micro-SD-Kartenleser auf dem ESP32-Board

## PN532

Bisher diskutierter Anschluss:

- GND
- IO22
- IO27
- 3V3

Die tatsächliche PN532-Schnittstelle muss mit dem verwendeten Modul und dessen Jumper-/Schalterstellung abgeglichen werden.

## Hinweis

GPIO-Belegung beim ESP32-2432S028 nicht ungeprüft aus dem generischen ESP32-Sketch übernehmen.
